# Shadow Proxy

This is a mobile-friendly website launcher. It accepts a website address and opens it in a new tab.

## Publish it free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new public repository named `shadow-proxy`.
3. Upload `index.html` from this folder.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The URL will be shown in the Pages section.

Note: this is not a true web proxy. It does not hide your IP address, fetch websites through a server, or bypass network restrictions. Some websites also prevent embedding or automated access.
